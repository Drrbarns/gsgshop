'use client';

export default function LiveSalesNotification() {
  return null;
}
