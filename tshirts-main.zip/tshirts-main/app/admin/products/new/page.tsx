'use client';

import ProductForm from '@/components/admin/ProductForm';

export default function NewProductPage() {
    return <ProductForm />;
}
